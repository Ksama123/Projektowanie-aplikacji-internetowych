# Nauka – Funkcja i `if`: bramkarz

## Cel

Funkcja dostaje wiek i decyduje, czy wpuścić osobę na imprezę. Logika `if` / `else` siedzi w funkcji, a w ramce tylko wywołujesz ją z różnymi liczbami.

## Przydatne

- Parametr `wiek` porównujesz z progiem 18. Operator `>=` obejmuje pełnoletność.
- Obie odpowiedzi (zaproszenie i odmowa) wypisujesz przez `document.write` wewnątrz funkcji, każda z `"<br>"`.
- W głównym skrypcie nie powtarzasz warunku — pytasz funkcję o działanie.
- Definicja w `<head>`, wywołania w `#wynik`.

## Wymagania

1. W `<head>` zdefiniuj funkcję `wpuscNaImpreze(wiek)`.
2. Gdy wiek jest co najmniej 18, wypisz „Zapraszamy! Masz ” oraz wiek i „ lat.”.
3. W przeciwnym razie wypisz „Niestety, wstęp od 18 lat.”.
4. W ramce `#wynik` wywołaj funkcję dla 15, 18 i 25.
5. W stopce wpisz swoje imię, nazwisko i klasę.

## Przykład

W ramce widać odmowę dla 15 lat, zaproszenie dla 18 lat i zaproszenie dla 25 lat.

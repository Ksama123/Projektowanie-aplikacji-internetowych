// Wpisz wzór poprawnie
let C = Number(prompt("Podaj temperature w stopniach celsjusza"))
let F = ((C*9)/5) + 32
document.write("Temperatura w stopniach Fahrenheita to: " + F + "F")
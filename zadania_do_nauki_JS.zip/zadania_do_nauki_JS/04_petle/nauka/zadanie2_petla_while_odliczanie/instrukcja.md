# Nauka – Pętla `while`: odliczanie

## Cel

Wypisz odliczanie od 10 do 0, a po ostatniej liczbie pokaż napis „START!”. Nauczysz się pętli `while`, w której warunek jest ważniejszy niż z góry znana liczba obrotów.

## Przydatne

- Licznik ustawiasz **przed** pętlą, na przykład `let licznik = 10;`.
- `while (warunek) { ... }` najpierw sprawdza warunek, a potem wykonuje blok.
- Wewnątrz pętli musisz sam zmienić licznik (na przykład `licznik--`). Bez tego warunek nigdy nie przestanie być prawdziwy i pętla nie skończy się.
- Napis „START!” dajesz **po** zamknięciu klamry pętli, żeby pojawił się tylko raz.
- Wypis: `document.write(...)`. Między liczbami możesz dać przecinek i spację.

## Wymagania

1. Zacznij odliczanie od 10 i schodź do 0 włącznie.
2. Użyj pętli `while`.
3. Po zakończeniu pętli wypisz „START!”.

## Przykład

Otwierasz stronę i widzisz liczby 10, 9, 8 … aż do 0, a zaraz potem napis „START!”.

// Wykonaj instrukcję krok po kroku
let imie = prompt("Jak masz na imię?")
let nazwisko = prompt("Jak masz na nazwisko?")
document.write("Witaj " + imie + " " + nazwisko + "!")
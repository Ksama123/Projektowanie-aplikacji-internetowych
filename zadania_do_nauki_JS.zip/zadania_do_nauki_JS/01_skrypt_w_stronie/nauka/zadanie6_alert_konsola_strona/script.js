// Twoje rozwiazanie
let imie = prompt("Jak masz na imię?")
document.write("Cześć, " + imie)
alert("Cześć, " + imie)
console.log("Cześć, " + imie)
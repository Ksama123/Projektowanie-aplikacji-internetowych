# Nauka – if/else: bilet do kina

## Cel

Dobierz cenę biletu: ulgowy 15 zł przy wieku poniżej 18 albo normalny 25 zł przy wieku 18 i więcej. Użyj `if/else`, żeby zawsze wybrać jedną z dwóch dróg.

## Przydatne

`if (warunek) { ... } else { ... }` wykonuje dokładnie jeden blok. Wiek zbierzesz przez `Number(prompt(...))` i porównasz operatorem `<` albo `>=`. Wynik wypiszesz przez `document.write`.

## Wymagania

1. Pobierz wiek.
2. Poniżej 18 lat pokaż bilet ulgowy 15 zł; w przeciwnym razie bilet normalny 25 zł.
3. Pokaż rodzaj biletu i cenę.

## Przykład

Otwórz `index.html`. W okienku wpisz `16` i zatwierdź. W ramce wyniku pojawia się „Bilet ulgowy, 15 zł”. Odśwież stronę i wpisz `18`. Tekst zmienia się na „Bilet normalny, 25 zł”. Przy `40` też widać bilet normalny.

# Nauka – Pętla `for`: powitanie

## Cel

Wypisz na stronie dziesięć razy zdanie „Programuję w JS!”, a przy każdym wierszu pokaż numer. Kod wpisujesz w `skrypt.js`. Nauczysz się zapisu pętli `for` i użycia licznika wewnątrz powtórzenia.

## Przydatne

- Pętla `for` ma w nawiasie trzy części: start, warunek końca i krok, na przykład `let i = 1`, potem warunek z `i` oraz `i++`.
- Licznik `i` możesz wstawić do tekstu operatorem `+`.
- Wypis: `document.write(...)`. Nowa linia: `"<br>"`.

## Wymagania

1. Użyj pętli `for`, która wykona się od 1 do 10 włącznie.
2. W każdym obrocie wypisz numer, kropkę, spację i zdanie „Programuję w JS!”.
3. Każdy napis ma być w osobnej linii.

## Przykład

Otwierasz `index.html` i na stronie widać dziesięć linii: „1. Programuję w JS!”, potem „2. Programuję w JS!” i tak dalej aż do „10. Programuję w JS!”.

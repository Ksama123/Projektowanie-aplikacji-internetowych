// Twoje rozwiazanie
let imie = prompt("Jak masz na imię")
let klasa = prompt("Jakiej klasy jesteś uczniem")

document.write(imie + "<br>" + klasa + "<br>" + "To moja wizytówka.")
console.log(imie + " " + klasa)
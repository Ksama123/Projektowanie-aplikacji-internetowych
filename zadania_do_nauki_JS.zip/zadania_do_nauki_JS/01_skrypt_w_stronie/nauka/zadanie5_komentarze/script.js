// Twoje rozwiazanie
// fajny komentarz
/*Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos sit placeat, rem nihil nesciunt eius atque quaerat numquam quod odio enim vel quibusdam labore facere dicta illum incidunt vitae ratione.
Dolore quod ratione unde dolorem aliquid nostrum alias facere consequatur? Itaque illo a expedita inventore, suscipit, quaerat quidem tempora fuga dolorum officia optio voluptate animi, hic corporis iure est! Sapiente?
Quia porro sed vero esse? Officia, odit iste consequuntur at totam culpa. Repellendus, facere eveniet. Placeat voluptatibus consectetur sint illo quisquam magni sapiente amet, quas praesentium atque quis! Modi, quo!
Amet delectus, possimus officia voluptatum nihil explicabo itaque rem maiores eius neque corrupti est velit omnis dolorum ipsa, error commodi. Quia minus eos recusandae alias veritatis doloremque fugiat ullam animi.
Eaque aliquid veniam quidem ex ipsam id iusto, totam aspernatur suscipit, quae, molestias velit necessitatibus distinctio! Consequuntur modi, perferendis ipsum molestiae velit doloremque quisquam adipisci reiciendis aperiam quasi exercitationem esse?*/
document.write("Komentarze OK")
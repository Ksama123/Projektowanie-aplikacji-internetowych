// Pobierz liczbę od użytkownika
// Zadeklaruj sumę
// Napisz pętlę for
// Wypisz wynik PO pętli

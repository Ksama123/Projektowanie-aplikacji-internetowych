// Zmienna na hasło
let haslo;

// Tutaj wpisz konstrukcję do...while

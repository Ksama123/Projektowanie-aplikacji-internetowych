// Pamiętaj o Number()!
let a = Number(prompt("Podaj bok a"))
let b = Number(prompt("Podaj bok b"))
let pole = a*b
let obwod = 2*a + 2*b
document.write("Pole to: " + pole + "<br>" + "Obwód to: " + obwod)
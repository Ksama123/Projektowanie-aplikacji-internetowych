// Tutaj wpisz swój kod
const OBECNY_ROK = 2026
let urodzenie = prompt("W jakim roku się urodziłeś?")
let wiek = OBECNY_ROK - urodzenie
document.write("Masz " + wiek + " lat")
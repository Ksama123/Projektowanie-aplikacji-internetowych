# Nauka – Wiele argumentów: pole prostokąta

## Cel

Funkcja dostaje dwa boki, liczy pole i wypisuje wynik w ramce `#wynik`. Ćwiczysz kolejność argumentów: pierwszy wpis trafia do pierwszego parametru.

## Przydatne

- W nawiasie definicji możesz podać kilka nazw oddzielonych przecinkiem, na przykład `a` i `b`.
- Pole to iloczyn boków. Wynik możesz trzymać w lokalnej zmiennej i dopiero potem wstawić do zdania.
- Kolejność ma znaczenie: `poleProstokata(5, 10)` to inne boki niż `poleProstokata(10, 5)`.
- Definicja w `<head>`, wywołania w `<script>` wewnątrz `#wynik`. Wypis: `document.write` i `"<br>"`.

## Wymagania

1. W `<head>` zdefiniuj funkcję `poleProstokata(a, b)`.
2. Wewnątrz policz pole i wypisz zdanie: „Pole prostokąta o bokach ” oraz oba boki i wynik.
3. W ramce `#wynik` wywołaj funkcję dla par `5, 10` oraz `2.5, 4`.
4. W stopce wpisz swoje imię, nazwisko i klasę.

## Przykład

Otwierasz stronę. W ramce widać, że pole dla boków 5 i 10 wynosi 50, a dla boków 2.5 i 4 wynosi 10.

// Twoje rozwiazanie
const imie = prompt("Jak masz na imię?")
document.write("Witaj, " + imie + "!")
// Przetestuj operatory ++, +=, -=
let punkty = 10;

document.write("Start: " + punkty)
punkty++
document.write("<br>Po walce: " + punkty)
punkty+=5
document.write("<br>Po skarbie: " + punkty)
punkty-=2
document.write("<br>Po pułapce: " + punkty)
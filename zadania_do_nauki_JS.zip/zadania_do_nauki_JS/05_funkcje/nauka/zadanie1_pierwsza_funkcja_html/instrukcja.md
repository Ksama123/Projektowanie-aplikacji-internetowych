# Nauka – Pierwsza funkcja

## Cel

Zdefiniuj prostą funkcję i wywołaj ją tak, żeby napis pojawił się w ramce `#wynik`. Nauczysz się, że funkcję najpierw się nazywa, a potem odpalasz jej nazwę z nawiasami.

## Przydatne

- Definicja zaczyna się od słowa `function`, potem nazwa i pusta para nawiasów, a ciało jest w klamrach.
- W semestrze 1 funkcja wypisuje tekst przez `document.write(...)`. Nie sięgamy po `getElementById`.
- Definicję dajesz w `<script>` w sekcji `<head>`. Wywołanie — w `<script>` wewnątrz ramki `#wynik`, żeby `write` wpadło w to pudełko.
- Wywołanie to nazwa i nawiasy: `powitanie();`.

## Wymagania

1. W `<head>` zdefiniuj funkcję o nazwie `powitanie`.
2. Wewnątrz funkcji wypisz „Witaj w świecie funkcji!”.
3. W ramce `#wynik` wywołaj `powitanie();`.
4. W stopce (`<footer>`) wpisz swoje imię, nazwisko i klasę.

## Przykład

Otwierasz `index.html`. W ramce `#wynik` widać „Witaj w świecie funkcji!”, a na dole strony Twoje dane w stopce.

// Twoje rozwiazanie
const szkola = "Technikum nr 12"
let imie = prompt("Jak masz na imię?")
document.write("Witaj, " + imie + "<br>" + szkola)
// Pętla for od 0 do 20
// Wewnątrz instrukcja if sprawdzająca parzystość (i % 2 == 0)
